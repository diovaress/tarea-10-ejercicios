import javax.swing.*;
import java.awt.*;

public class VentanaEstudiante extends JFrame {
    private JTextField txtNombre, txtEdad, txtNotas;
    private JTextArea areaResultados;
    private Estudiante[] estudiantes;
    private int contador = 0;

    public VentanaEstudiante() {
        estudiantes = new Estudiante[3];

        setTitle("informe de alumnos ");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        add(new JLabel("nombre:"));
        txtNombre = new JTextField(30);
        add(txtNombre);

        add(new JLabel("edad:"));
        txtEdad = new JTextField(20);
        add(txtEdad);

        add(new JLabel("calificaciones; ingresar_5_separadas por (,)"));



        txtNotas = new JTextField(15);
        add(txtNotas);

        JButton btnAgregar = new JButton("ingresar");
        add(btnAgregar);
        btnAgregar.addActionListener(e -> agregarEstudiante());

        JButton btnMostrar = new JButton("Mostrar Promedios");
        add(btnMostrar);
        btnMostrar.addActionListener(e -> mostrarPromedios());

        areaResultados = new JTextArea(10, 35);
        areaResultados.setEditable(false);
        add(new JScrollPane(areaResultados));
    }

    private void agregarEstudiante() {
        if (contador < 3) {
            try {
                String nombre = txtNombre.getText().trim();
                int edad = Integer.parseInt(txtEdad.getText().trim());
                String[] notasTexto = txtNotas.getText().trim().split(",");
                if (notasTexto.length != 5) throw new NumberFormatException();

                double[] notas = new double[5];
                for (int i = 0; i < 5; i++) {
                    notas[i] = Double.parseDouble(notasTexto[i]);
                }

                estudiantes[contador] = new Estudiante(nombre, edad, notas);
                contador++;
                txtNombre.setText("");
                txtEdad.setText("");
                txtNotas.setText("");

                if (contador == 3) {
                    JOptionPane.showMessageDialog(this, "Listado completado, mostrar  resultados.", "Informacion", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Ingrese datos almenos validos", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Ya se  ingresaron   3 estudiantes.", "el limite fue  alcanzado", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void mostrarPromedios() {
        areaResultados.setText("Promedios de los alumnos :\n");
        for (int i = 0; i < contador; i++) {
            areaResultados.append(estudiantes[i].getNombre() + " - Promedio: " + String.format("%.2f", estudiantes[i].calcularPromedio()) + "\n");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new VentanaEstudiante().setVisible(true));
    }
}
