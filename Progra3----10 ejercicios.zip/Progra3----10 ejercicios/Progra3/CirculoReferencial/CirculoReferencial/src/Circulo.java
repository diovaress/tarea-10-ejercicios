class Circulo {
    private double radio;

    // Constructor
    public Circulo(double radio) {
        this.radio = radio;
    }

    // Método para calcular el área
    public double calcularArea() {
        return Math.PI * Math.pow(radio, 2);
    }

    // Método para calcular la circunferencia
    public double calcularCircunferencia() {
        return 2 * Math.PI * radio;
    }

    // Getter del radio
    public double getRadio() {
        return radio;
    }

    // Setter para actualizar el radio
    public void setRadio(double radio) {
        this.radio = radio;
    }
}

