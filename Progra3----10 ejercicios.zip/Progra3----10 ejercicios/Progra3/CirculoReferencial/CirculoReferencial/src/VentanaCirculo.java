import javax.swing.*;
import java.awt.*;

public class VentanaCirculo extends JFrame {
    private Circulo circulo;
    private JLabel labelArea, labelCircunferencia, labelMensaje;
    private JTextField textFieldRadio;
    private JButton btnActualizar;

    public VentanaCirculo() {
        // Inicializamos el círculo con un radio por defecto
        circulo = new Circulo(50); // Radio inicial 50 píxeles

        // Configuración de la ventana
        setTitle("Círculo: Área y Circunferencia");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Panel para dibujar el círculo
        JPanel panelDibujo = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                // Dibujar el círculo con el radio especificado
                g.setColor(Color.BLUE);
                g.fillOval(150, 50, (int)(circulo.getRadio() * 2), (int)(circulo.getRadio() * 2)); // Círculo
            }
        };

        // Crear las etiquetas para mostrar área y circunferencia
        labelArea = new JLabel("Área: " + String.format("%.2f", circulo.calcularArea()) + " unidades cuadradas");
        labelCircunferencia = new JLabel("Circunferencia: " + String.format("%.2f", circulo.calcularCircunferencia()) + " unidades");
        labelMensaje = new JLabel("Ingrese el radio del círculo:");

        // Crear un campo de texto para que el usuario ingrese el radio
        textFieldRadio = new JTextField(10);
        textFieldRadio.setText(String.valueOf(circulo.getRadio())); // Mostrar el radio actual

        // Crear el botón para actualizar el círculo
        btnActualizar = new JButton("Actualizar Círculo");
        btnActualizar.addActionListener(e -> actualizarCirculo());

        // Añadir componentes a la ventana
        JPanel panelTexto = new JPanel();
        panelTexto.setLayout(new BoxLayout(panelTexto, BoxLayout.Y_AXIS));
        panelTexto.add(labelMensaje);
        panelTexto.add(textFieldRadio);
        panelTexto.add(btnActualizar);
        panelTexto.add(labelArea);
        panelTexto.add(labelCircunferencia);

        add(panelDibujo, BorderLayout.CENTER);
        add(panelTexto, BorderLayout.SOUTH);

        // Hacer visible la ventana
        setVisible(true);
    }

    // Método para actualizar el círculo con el nuevo radio y los cálculos
    private void actualizarCirculo() {
        try {
            double nuevoRadio = Double.parseDouble(textFieldRadio.getText());
            if (nuevoRadio <= 0) {
                JOptionPane.showMessageDialog(this, "El radio debe ser un número positivo", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                circulo.setRadio(nuevoRadio);  // Actualizamos el radio del círculo
                labelArea.setText("Área: " + String.format("%.2f", circulo.calcularArea()) + " unidades cuadradas");
                labelCircunferencia.setText("Circunferencia: " + String.format("%.2f", circulo.calcularCircunferencia()) + " unidades");
                repaint();  // Redibujamos el círculo con el nuevo radio
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Ingrese un número válido para el radio", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        // Ejecutar la aplicación
        SwingUtilities.invokeLater(() -> new VentanaCirculo());
    }
}

