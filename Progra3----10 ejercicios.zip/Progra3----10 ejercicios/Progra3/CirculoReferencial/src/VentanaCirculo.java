import javax.swing.*;
import java.awt.*;

public class VentanaCirculo extends JFrame {
    private Circulo circulo;
    private JLabel labelArea, labelCircunferencia, labelMensaje;
    private JTextField textFieldRadio;
    private JButton btnActualizar;

    public VentanaCirculo() {

        circulo = new Circulo(70);


        setTitle("Círculo  y su respectiva Área y Circunferencia");
        setSize(410, 410);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel panelDibujo = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);

                g.setColor(Color.BLUE);
                g.fillOval(160, 60, (int)(circulo.getRadio() * 2), (int)(circulo.getRadio() * 2));
            }
        };

        labelArea = new JLabel("area: " + String.format("%.2f", circulo.calcularArea()) + "elementos  cuadrados");
        labelCircunferencia = new JLabel("circunferencia: " + String.format("%.2f", circulo.calcularCircunferencia()) + " elementos");
        labelMensaje = new JLabel("escriba el radio del criculo:");


        textFieldRadio = new JTextField(10);
        textFieldRadio.setText(String.valueOf(circulo.getRadio()));


        btnActualizar = new JButton("actualizar");
        btnActualizar.addActionListener(e -> actualizarCirculo());


        JPanel panelTexto = new JPanel();
        panelTexto.setLayout(new BoxLayout(panelTexto, BoxLayout.Y_AXIS));
        panelTexto.add(labelMensaje);
        panelTexto.add(textFieldRadio);
        panelTexto.add(btnActualizar);
        panelTexto.add(labelArea);
        panelTexto.add(labelCircunferencia);

        add(panelDibujo, BorderLayout.CENTER);
        add(panelTexto, BorderLayout.SOUTH);

        setVisible(true);
    }


    private void actualizarCirculo() {
        try {
            double nuevoRadio = Double.parseDouble(textFieldRadio.getText());
            if (nuevoRadio <= 0) {
                JOptionPane.showMessageDialog(this, "El radio almenos tiene que ser un número positivo", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                circulo.setRadio(nuevoRadio);
                labelArea.setText("Área: " + String.format("%.2f", circulo.calcularArea()) + " elementos cuadrads");
                labelCircunferencia.setText("Circunferencia: " + String.format("%.2f", circulo.calcularCircunferencia()) + " unidades");
                repaint();
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Ingrese un numero  para el radio", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> new VentanaCirculo());
    }
}

