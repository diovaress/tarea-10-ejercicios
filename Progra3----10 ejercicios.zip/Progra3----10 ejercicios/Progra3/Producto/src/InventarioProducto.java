import javax.swing.*;
import java.util.ArrayList;

public class InventarioProducto {
    public static void main(String[] args) {

        ArrayList<Producto> productos = new ArrayList<>();
        String menu = "1. ingresar Producto\n2. ver Productos\n3. Calcular Total\n4. Salir";
        int opcion;

        do {

            opcion = Integer.parseInt(JOptionPane.showInputDialog(menu));

            switch (opcion) {
                case 1:

                    String nombre = JOptionPane.showInputDialog("Ingrese el nombre del producto:");
                    double precio = Double.parseDouble(JOptionPane.showInputDialog("ingresar el precio:"));
                    int cantidad = Integer.parseInt(JOptionPane.showInputDialog("ingrese la cantidad:"));


                    Producto nuevoProducto = new Producto(nombre, precio, cantidad);
                    productos.add(nuevoProducto);
                    JOptionPane.showMessageDialog(null, "Producto agregado al carrito.");
                    break;

                case 2:

                    if (productos.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "no existe  en el inventario.");
                    } else {
                        StringBuilder lista = new StringBuilder("listado  de Productos:\n");
                        for (Producto producto : productos) {
                            lista.append(producto.toString()).append("\n");
                        }
                        JOptionPane.showMessageDialog(null, lista.toString());
                    }
                    break;

                case 3:

                    double valorTotal = 0;

                    for (Producto producto : productos) {
                        valorTotal += producto.calcularValor();
                    }
                    JOptionPane.showMessageDialog(null, " valor total del inventario es: " + valorTotal);
                    break;

                case 4:

                    JOptionPane.showMessageDialog(null, "vuelva pronto");
                    break;

                default:
                    JOptionPane.showMessageDialog(null, "error intene de nuevo.");
            }
        } while (opcion != 4);
    }
}
