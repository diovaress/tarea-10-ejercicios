import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.Collections;

public class OrdenarNumeros extends JFrame {
    private JTextField txtNumero;
    private JTextArea areaResultado;
    private ArrayList<Integer> numeros;

    public OrdenarNumeros() {
        numeros = new ArrayList<>();

        setTitle("Ordenar numeros");
        setSize(450, 250);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        add(new JLabel("ingrese almenos un numero:"));
        txtNumero = new JTextField(12);
        add(txtNumero);

        JButton btnAgregar = new JButton("agregar");
        add(btnAgregar);
        btnAgregar.addActionListener(this::agregarNumero);

        JButton btnOrdenar = new JButton("ordenar");
        add(btnOrdenar);
        btnOrdenar.addActionListener(this::ordenarLista);

        areaResultado = new JTextArea(12, 27);
        areaResultado.setEditable(false);
        add(new JScrollPane(areaResultado));
    }

    private void agregarNumero(ActionEvent e) {
        try {
            int num = Integer.parseInt(txtNumero.getText().trim());
            numeros.add(num);
            txtNumero.setText("");
            actualizarLista();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "ingresar almenos un numero valido.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void ordenarLista(ActionEvent e) {
        if (numeros.isEmpty()) {
            JOptionPane.showMessageDialog(this, "no existe aun numers a ordenar .", "nota", JOptionPane.WARNING_MESSAGE);
            return;
        }
        Collections.sort(numeros);
        actualizarLista();
    }

    private void actualizarLista() {
        areaResultado.setText("listado de los  numeros:\n" + numeros.toString());
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new OrdenarNumeros().setVisible(true));
    }
}
