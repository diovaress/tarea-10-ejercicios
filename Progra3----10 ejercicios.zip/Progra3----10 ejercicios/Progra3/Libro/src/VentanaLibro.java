import javax.swing.*;
import java.awt.*;

public class VentanaLibro extends JFrame {
    private JTextField txtTitulo, txtAutor, txtAnio, txtPrecio;
    private JTextArea resultado;

    public VentanaLibro() {
        setTitle("Calculadora de Precio ");
        setSize(650, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        add(new JLabel("titulo:"));
        txtTitulo = new JTextField(20);
        add(txtTitulo);

        add(new JLabel("Autor:"));
        txtAutor = new JTextField(25);
        add(txtAutor);

        add(new JLabel("Año Publicación:"));
        txtAnio = new JTextField(30);
        add(txtAnio);

        add(new JLabel("costo:"));
        txtPrecio = new JTextField(10);
        add(txtPrecio);

        JButton btnCalcular = new JButton("Calcular costo");
        add(btnCalcular);
        btnCalcular.addActionListener(e -> calcularPrecio());

        resultado = new JTextArea(3, 20);
        resultado.setEditable(false);
        add(new JScrollPane(resultado));
    }

    private void calcularPrecio() {
        try {
            String titulo = txtTitulo.getText();
            String autor = txtAutor.getText();
            int anio = Integer.parseInt(txtAnio.getText());
            double precio = Double.parseDouble(txtPrecio.getText());

            Libro libro = new Libro(titulo, autor, anio, precio);
            double precioFinal = libro.calcularDescuento();

            resultado.setText("Precio añadido descuento: Q" + String.format("%.2f", precioFinal));
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Ingrese datos validos", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new VentanaLibro().setVisible(true));
    }
}
