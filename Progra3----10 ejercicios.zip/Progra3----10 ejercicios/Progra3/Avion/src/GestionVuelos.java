import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GestionVuelos extends JFrame {
    private Vuelo[] vuelos;
    private JComboBox<String> comboVuelos;
    private JTextField txtPasajero;
    private JLabel lblCostoPasaje;

    public GestionVuelos() {
        vuelos = new Vuelo[]{
                new Vuelo(103, "Guatemala", "honduras", 260.0),
                new Vuelo(102, "Guatemala", "tailandia", 8200.0),
                new Vuelo(105, "Guatemala", "korea del norte.", 440.0),
                new Vuelo(104, "Guatemala", "china", 620.0),
                new Vuelo(106, "Guatemala", "japo", 520.0)
        };

        setTitle("gestion de Vuelos");
        setSize(450, 350);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;


        gbc.gridx = 0;
        gbc.gridy = 0;
        add(new JLabel("Selecciona el vuelo:"), gbc);

        gbc.gridx = 1;
        comboVuelos = new JComboBox<>();
        for (Vuelo vuelo : vuelos) {
            comboVuelos.addItem("Vuelo " + vuelo.getNumeroVuelo() + " - " + vuelo.getDestino());
        }
        comboVuelos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                actualizarCostoPasaje();
            }
        });
        add(comboVuelos, gbc);


        gbc.gridx = 0;
        gbc.gridy = 1;
        add(new JLabel("precio de pasaje:"), gbc);

        gbc.gridx = 1;
        lblCostoPasaje = new JLabel("Q" + vuelos[0].getCostoPasaje());
        add(lblCostoPasaje, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        add(new JLabel("Nombre del pasajero:"), gbc);

        gbc.gridx = 1;
        txtPasajero = new JTextField(15);
        add(txtPasajero, gbc);


        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        JButton btnAgregar = new JButton("Agregar Pasajero");
        add(btnAgregar, gbc);
        btnAgregar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                agregarPasajero(e);
            }
        });


        gbc.gridy = 4;
        JButton btnMostrar = new JButton("ver Pasajeros");
        add(btnMostrar, gbc);
        btnMostrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarPasajeros(e);
            }
        });

        gbc.gridy = 5;
        JButton btnBuscar = new JButton("buscar pasajero");
        add(btnBuscar, gbc);
        btnBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buscarPasajero(e);
            }
        });

        actualizarCostoPasaje();
    }

    private void actualizarCostoPasaje() {
        int indice = comboVuelos.getSelectedIndex();
        lblCostoPasaje.setText("Q" + vuelos[indice].getCostoPasaje());
    }

    private void agregarPasajero(ActionEvent e) {
        int indice = comboVuelos.getSelectedIndex();
        String nombre = txtPasajero.getText().trim();
        if (!nombre.isEmpty()) {
            vuelos[indice].agregarPasajero(nombre);
            JOptionPane.showMessageDialog(this, "Pasajero añadido al vuelo.", "guardado", JOptionPane.INFORMATION_MESSAGE);
            txtPasajero.setText("");
        } else {
            JOptionPane.showMessageDialog(this, "ingresar un nombre que sea valido .", "error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void mostrarPasajeros(ActionEvent e) {
        int indice = comboVuelos.getSelectedIndex();
        Vuelo vuelo = vuelos[indice];

        new VentanaPasajeros(vuelo).setVisible(true);
    }

    private void buscarPasajero(ActionEvent e) {
        String nombre = txtPasajero.getText().trim();
        if (nombre.isEmpty()) {
            JOptionPane.showMessageDialog(this, "ingresar un nombre para  inciar busqueda.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        StringBuilder resultado = new StringBuilder("bisqueda de: " + nombre + "\n");
        boolean encontrado = false;

        for (Vuelo vuelo : vuelos) {
            if (vuelo.buscarPasajero(nombre)) {
                resultado.append("ya en  Vuelo ").append(vuelo.getNumeroVuelo()).append(" a ").append(vuelo.getDestino()).append("\n");
                encontrado = true;
            }
        }

        if (!encontrado) {
            resultado.append(" no fue posible encontrar al pasajero asignado al vuelo.\n");
        }

        JOptionPane.showMessageDialog(this, resultado.toString(), "resulatado de busqueda", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new GestionVuelos().setVisible(true);
            }
        });
    }
}

class VentanaPasajeros extends JFrame {
    private Vuelo vuelo;
    private JTextArea areaPasajeros;

    public VentanaPasajeros(Vuelo vuelo) {
        this.vuelo = vuelo;

        setTitle("pasajeros en el vuelo " + vuelo.getNumeroVuelo());
        setSize(400, 300);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        areaPasajeros = new JTextArea(10, 30);
        areaPasajeros.setEditable(false);

        JScrollPane scroll = new JScrollPane(areaPasajeros);
        add(scroll, BorderLayout.CENTER);

        mostrarPasajeros();
    }

    private void mostrarPasajeros() {
        java.util.ArrayList<String> listaPasajeros = vuelo.getPasajeros();
        areaPasajeros.setText("Pasajeros en el vuelo " + vuelo.getNumeroVuelo() + " (" + vuelo.getDestino() + "):\n");

        if (listaPasajeros.isEmpty()) {
            areaPasajeros.append("no existe aun pasajeros registrados en este vuelo.\n");
        } else {
            for (String pasajero : listaPasajeros) {
                areaPasajeros.append("- " + pasajero + "\n");
            }
        }
    }
}
